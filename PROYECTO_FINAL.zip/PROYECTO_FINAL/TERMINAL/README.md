# Emulador de Terminal

Para ejecutar el emulador de terminal, asegúrate de tener Python instalado y ejecuta el siguiente comando en tu terminal:

```bash
python emulador.py
