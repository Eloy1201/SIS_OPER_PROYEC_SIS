from flask import Flask, request, jsonify
import os
import shutil

app = Flask(__name__)

@app.route('/command', methods=['POST'])
def command():
    data = request.json
    cmd = data.get('command', '').strip()
    current_dir = data.get('current_dir', os.getcwd())

    try:
        os.chdir(current_dir)
    except FileNotFoundError:
        return jsonify({"error": "Directory not found"}), 400

    if cmd == "ls":
        output = os.listdir()
    elif cmd == "pwd":
        output = os.getcwd()
    elif cmd.startswith("cd "):
        path = cmd[3:].strip()
        try:
            os.chdir(path)
            output = ""
        except FileNotFoundError:
            output = "No such directory"
        current_dir = os.getcwd()
    elif cmd.startswith("mkdir "):
        path = cmd[6:].strip()
        os.makedirs(path, exist_ok=True)
        output = f"Directory {path} created"
    elif cmd.startswith("touch "):
        path = cmd[6:].strip()
        with open(path, 'a'):
            os.utime(path, None)
        output = f"File {path} touched"
    elif cmd.startswith("rm "):
        path = cmd[3:].strip()
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
                output = f"Directory {path} removed"
            else:
                os.remove(path)
                output = f"File {path} removed"
        except FileNotFoundError:
            output = "No such file or directory"
    elif cmd.startswith("cat "):
        path = cmd[4:].strip()
        try:
            with open(path, 'r') as file:
                output = file.read()
        except FileNotFoundError:
            output = "No such file"
    elif cmd == "clear":
        output = ""
    else:
        output = "Command not recognized"

    return jsonify({"output": output, "current_dir": current_dir})

if __name__ == '__main__':
    app.run(debug=True)
