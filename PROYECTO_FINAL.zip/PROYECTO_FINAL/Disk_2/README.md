# io-management
fcfs, sstf, scan, cscan, look, and clook algorithms
